// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

// Define buffer max
const int MAX_BUFFER = 21;

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_number
	//  variable, and its position in the declaration. It must always be directly before the variable used for input.
	//  You must notify the user if they entered too much data.

	const std::string account_number = "CharlieBrown42";
	char user_input[MAX_BUFFER];
	std::cout << "Enter a value: ";

	// Get user input and check for length, limiting to max buffer to prevent overflow
	if (std::cin.getline(user_input, MAX_BUFFER)) {

		// return account number if acceptable length
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}

	// if input was too long, return error statement
	else {
		std::cout << "Maxiumim character length of " << MAX_BUFFER - 1<< " exceeded! " << std::endl;

	}

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
